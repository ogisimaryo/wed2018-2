var who='world';function sayhello(){alert('Hello,'+who+'!');}
function someone(x){who=x;}




<h1>引数の練習</h1>
<input type="button"value="あいさつ”onclick="sayhello();">
<input type="button"value="太郎”onclick="sayhello(太郎);">
<input type="button"value="花子”onclick="sayhello(花子);">
